import {
  Directive,
  Output,
  EventEmitter,
  HostListener,
  ElementRef,
} from '@angular/core';

@Directive({
  selector: '[appDroppable]'
})
export class DroppableDirective {

  constructor(private elementRef: ElementRef) {}

  @Output() acDrop = new EventEmitter();

  @HostListener('dragenter', ['$event'])
  onDragEnter(event:any) {
    this.elementRef.nativeElement.classList.add('over');
    return false;
  }
  @HostListener('dragover', ['$event'])
  onDragOver(event:any) {
    event.dataTransfer.dropEffect = 'move';
    // if (event.preventDefault) {
    //   event.preventDefault();
    // }
    if (typeof event === 'undefined') {
      event = window.event;
    }
    this.stopDefaultAction(event);
    this.elementRef.nativeElement.classList.add('over');
    return false;
  }
  @HostListener('dragleave', ['$event'])
  onDragLeave(event:any) {
    this.elementRef.nativeElement.classList.remove('over');
    return false;
  }
  @HostListener('drop', ['$event'])
  onDrop(event:any) {
    // if (event.stopPropagation) {
    //   event.stopPropagation();
    // }
    if (typeof event === 'undefined') {
      event = window.event;
    }
    this.stopDefaultAction(event);
    this.elementRef.nativeElement.classList.remove('over');
    const data = JSON.parse(event.dataTransfer.getData('Text'));
    this.acDrop.next(
      Object.assign(data, { coords: { x: event.offsetX, y: event.offsetY } })
    );
    // this.acDrop.next(Object.assign(data));
  }

  stopDefaultAction(event:any) {
    event.returnValue = false;

    if (typeof event.preventDefault !== 'undefined') {
      event.preventDefault();
    }
  }

  stopEvent(event:any) {
    if (typeof event.stopPropagation !== 'undefined') {
      event.stopPropagation();
    } else {
      event.cancelBubble = true;
    }
  }
}
