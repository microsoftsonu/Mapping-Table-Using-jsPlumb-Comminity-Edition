import {
  Directive,
  HostBinding,
  Input,
  HostListener,
  ElementRef,
} from '@angular/core';

@Directive({
  selector: '[acDraggable]'
})
export class DraggableDirective {
  private data: any;

  constructor(private elementRef: ElementRef) {}

  @HostBinding('draggable')
  get draggable() {
    return true;
  }

  @Input()
  set acDraggable(data:any) {
    this.data = data;
  }

  @HostListener('dragstart', ['$event'])
  onDragStart(event:any) {
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('Text', JSON.stringify(this.data));
    this.elementRef.nativeElement.classList.add('drag');
    // return false;
  }

  @HostListener('dragend', ['$event'])
  onDragEnd(event:any) {
    this.elementRef.nativeElement.classList.remove('drag');
    // return false;
  }
}
