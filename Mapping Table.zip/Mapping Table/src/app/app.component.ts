import { Component, OnInit, ElementRef } from '@angular/core';
import { jsPlumb } from 'jsplumb';
import DragSelect from 'dragselect';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'jsplumb-app';

  private defaultOptions: any = {
    PaintStyle: { strokeWidth: 2, stroke: '#4caf50' },
    HoverPaintStyle: { strokeWidth: 3, stroke: 'orange' },
    Connector: ['Bezier', { curviness: 150 }],
    ConnectorStyle: { stroke: '#4caf50', strokeWidth: 2 },
    Endpoint: ['Dot', { radius: 5 }],
    EndpointStyle: { fill: '#4caf50' },
    Anchors: ["Left", "Right"]
  };

  actions = [
    { label: 'Action1', color: '#8946A6', datatype: 'type1', records: this.getRecords() },
    { label: 'Action2', color: '#086E7D', datatype: 'type2', records: this.getRecords() },
    { label: 'Action3', color: '#f44336', datatype: 'type3', records: this.getRecords() },
    { label: 'Action4', color: '#8fce00', datatype: 'type4', records: this.getRecords() },
    { label: 'Action5', color: '#e69138', datatype: 'type5', records: this.getRecords() },

  ];

  nodes: any[] = [];

  jsPlumbInstance: any;

  constructor(private el: ElementRef) { }
  ngAfterViewInit() {
    this.jsPlumbInstance.bind("connection", (info: any) => {
      console.log("Connection made:", info.connection);
    });

    // Log connections after some delay
    setTimeout(() => {
      console.log("All connections:", this.jsPlumbInstance.getAllConnections());
    }, 500);
  }

  ngOnInit() {
    this.jsPlumbInstance = jsPlumb.getInstance(this.defaultOptions);
    this.jsPlumbInstance.setContainer(this.el.nativeElement);

    this.addEndpointsToActions();
  }

  getRecords() {
    return [
      { ColumnName: 'Column 1', dataType: 'String' },
      { ColumnName: 'Column 2', dataType: 'Boolean' },
      { ColumnName: 'Column 3', dataType: 'Double' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      { ColumnName: 'Column 4', dataType: 'Char' },
      // Add more records as needed
    ];
  }

  setMultiSelect() {
    setTimeout(() => {
      const selectables = Array.from(this.el.nativeElement.querySelectorAll('.jtk-draggable')) as HTMLElement[];

      const dragSelect = new DragSelect({
        selectables: selectables,
        multiSelectKeys: ['ctrlKey', 'shiftKey', 'metaKey'],
      });

      dragSelect.subscribe('elementselect', ({ items }) => {
        items.forEach((e: HTMLElement) => {
          console.log('Element selected:', e);
          this.jsPlumbInstance.addToDragSelection(e);
          e.style.border = '1px solid red';
        });
      });

      dragSelect.subscribe('elementunselect', ({ items }) => {
        items.forEach((e: HTMLElement) => {
          e.style.border = '1px solid grey';
          this.jsPlumbInstance.clearDragSelection();
        });
      });
    }, 1000);
  }

  addNode(event: any) {
    const nodeId = Date.now();
    const node = {
      data: {
        ...event.data,
        label: event.data.label + '_' + nodeId,
        id: nodeId,
        records: JSON.parse(JSON.stringify(this.getRecords()))
      },
      coords: event.coords,
    };
    this.nodes.push(node);

    setTimeout(() => {
      const ele = this.el.nativeElement.querySelector(`[id="${node.data.id}"]`) as HTMLElement;
      this.jsPlumbInstance.draggable(ele, {
        containment: this.el.nativeElement.querySelector('#jsplumb-container') as HTMLElement,
        stop: (event: any, ui: any) => {
          node.coords.x = ele.offsetLeft;
          node.coords.y = ele.offsetTop;
        },
      });
      this.addEndpointsToNode(node);
      this.setMultiSelect();
    }, 100);
  }

  addEndpointsToActions() {
    setTimeout(() => {
      this.actions.forEach(action => {
        action.records.forEach(record => {
          const rowId = `action-row-${action.label}-${record.ColumnName}`;
          const rowElement = this.el.nativeElement.querySelector(`#${rowId}`);
          if (rowElement) {
            this.jsPlumbInstance.addEndpoint(rowElement, {
              anchor: "Left",
              isSource: true,
              isTarget: true,
              connectorOverlays: [
                ['Arrow', { width: 10, length: 15, location: 0.5, id: 'arrow' }],
              ],
            });
            this.jsPlumbInstance.addEndpoint(rowElement, {
              anchor: "Right",
              isSource: true,
              isTarget: true,
              connectorOverlays: [
                ['Arrow', { width: 10, length: 15, location: 0.5, id: 'arrow' }],
              ],
            });
          } else {
            console.error(`Row element with ID ${rowId} not found`);
          }
        });
      });
    }, 100);
  }



  addEndpointsToNode(node: any) {
    const ele = this.el.nativeElement.querySelector(`[id="${node.data.id}"]`) as HTMLElement;
    if (ele) {
      const tableRows = Array.from(ele.querySelectorAll('tbody tr')) as HTMLElement[];

      tableRows.forEach((row: HTMLElement, index: number) => {
        const rowId = `node-row-${node.data.id}-${index}`;
        row.id = rowId;
        this.jsPlumbInstance.addEndpoint(row, {
          anchor: "Left",
          isSource: true,
          isTarget: true,
          connectorOverlays: [
            ['Arrow', { width: 10, length: 15, location: 0.5, id: 'arrow' }],
          ],
        });
        this.jsPlumbInstance.addEndpoint(row, {
          anchor: "Right",
          isSource: true,
          isTarget: true,
          connectorOverlays: [
            ['Arrow', { width: 10, length: 15, location: 0.5, id: 'arrow' }],
          ],
        });
      });
      this.jsPlumbInstance.draggable(ele);
      this.setMultiSelect();
    } else {
      console.error(`Element with ID ${node.data.id} not found`);
    }
  }


  generateJSON() {
    const nodes = this.nodes.map(node => ({
      id: node.data.id,
      label: node.data.label,
      columns: node.data.records.map((record: any) => ({
        name: record.ColumnName,
        type: record.dataType
      }))
    }));

    const connections = this.jsPlumbInstance.getAllConnections().map((conn: any) => {
      const sourceElement = conn.source;
      const targetElement = conn.target;
      // const sourceEndpoint = conn.sourceEndpoint;
      // const targetEndpoint = conn.targetEndpoint;

      if (!sourceElement || !targetElement) {
        console.error('Invalid connection:', conn);
        return null;
      }

      console.log(`Source ID: ${sourceElement.id}, Target ID: ${targetElement.id}`);
      // console.log('Source Endpoint:', sourceEndpoint);
      // console.log('Target Endpoint:', targetEndpoint);

      return {
        sourceNodeId: conn.sourceId,
        //sourceColumnId: sourceEndpoint.element.id,
        targetNodeId: conn.targetId,
        // targetColumnId: targetEndpoint.element.id
      };
    }).filter((conn: any) => conn !== null);

    const jsonOutput = { nodes, connections };
    console.log(JSON.stringify(jsonOutput, null, 2));
  }


  createConnection(sourceId: string, targetId: string) {
    this.jsPlumbInstance.connect({
      source: sourceId,
      target: targetId,
      overlays: [
        ['Arrow', { width: 10, length: 15, location: 0.5 }],
      ],
    });
  }
}
